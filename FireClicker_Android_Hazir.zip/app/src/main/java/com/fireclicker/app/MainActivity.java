package com.fireclicker.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {

    private WebView webView;
    private RewardedAd rewardedAd;
    private boolean isLoadingAd = false;
    private boolean rewardEarned = false;

    // Fire Clicker Rewarded Ad Unit ID
    private static final String REWARDED_AD_ID =
            "ca-app-pub-5350148501002208/7224333523";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MobileAds.initialize(this, initializationStatus -> loadRewardedAd());

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new AdBridge(), "AndroidAdMob");
        webView.loadUrl("file:///android_asset/index.html");

        setContentView(webView);
    }

    private void loadRewardedAd() {
        if (isLoadingAd || rewardedAd != null) return;

        isLoadingAd = true;
        AdRequest request = new AdRequest.Builder().build();

        RewardedAd.load(this, REWARDED_AD_ID, request,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedAd ad) {
                        isLoadingAd = false;
                        rewardedAd = ad;
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError error) {
                        isLoadingAd = false;
                        rewardedAd = null;
                        notifyJavascript("window.fireClickerAdFailed && window.fireClickerAdFailed()");
                    }
                });
    }

    private void notifyJavascript(String javascript) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(javascript, null);
        });
    }

    private class AdBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    loadRewardedAd();
                    notifyJavascript("window.fireClickerAdFailed && window.fireClickerAdFailed()");
                    return;
                }

                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                rewardEarned = false;
                loadRewardedAd();

                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        if (!rewardEarned) {
                            notifyJavascript("window.fireClickerAdFailed && window.fireClickerAdFailed()");
                        }
                        loadRewardedAd();
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        rewardEarned = false;
                        notifyJavascript("window.fireClickerAdFailed && window.fireClickerAdFailed()");
                        loadRewardedAd();
                    }
                });

                ad.show(MainActivity.this, rewardItem -> {
                    rewardEarned = true;
                    notifyJavascript("window.fireClickerReward && window.fireClickerReward()");
                });
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidAdMob");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
