# Fire Clicker Android

Hazır Android/WebView projesi. İçinde Fire Clicker HTML, Firebase ve Rewarded AdMob bağlantısı bulunur.

AdMob:
- App ID: ca-app-pub-5350148501002208~7915607821
- Rewarded Ad Unit ID: ca-app-pub-5350148501002208/7224333523

GitHub Actions:
- Debug APK üretir.
- Release AAB üretir.

ÖNEMLİ:
Google Play'e yüklemeden önce release AAB'yi bir Play App Signing/keystore süreciyle imzalamalısın. Bu paket otomatik olarak imzalı Play sürümü üretmez.

Telefonla kullanım:
1. ZIP'i GitHub repository'ne yükle.
2. Actions > Build Fire Clicker > Run workflow.
3. İşlem bitince Artifacts bölümünden APK/AAB indir.

Not: Gerçek AdMob reklamları yayın öncesi test edilirken Google'ın test reklam politikalarına uyulmalıdır.
